#' @title Sample Data for Analysis
#'
#' @description The data used here refer epidemiologic measured.
#'
#' @format A data frame with 122 row (agricultural explotation) and 15 columns (variables).

"antibiotic"
